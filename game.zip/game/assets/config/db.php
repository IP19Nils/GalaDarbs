<?php

$host = "localhost";
$username = "skolnieks";
$password = "pQcM10ClEn3lSWy";
$dbname = "NilsP";

// Create connection
$conn = new mysqli($host, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
